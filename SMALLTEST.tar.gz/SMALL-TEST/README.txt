Command to repeat SMALL-TEST:

python batched_train_pairhmm.py --config-folder CONFIGS

trains several single and mixture models on DEV-DATA_pair_alignments/FiveSamp
